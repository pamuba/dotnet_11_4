﻿using MagicVilla_VillaAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace MagicVilla_VillaAPI.Data
{
    public class ApplicationDbContext: DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options)
        {
                        
        }
        public DbSet<LocalUser> localUsers { get; set; }
        public DbSet<Villa> Villas { get; set; }
        public DbSet<VillaNumber> VillaNumbers { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Villa>().HasData(
                new Villa() { 
                    Id = 1,
                    Name = "Royal Villa",
                    Details = "Dapper is a simple and effective tool for retrieving scalar values from databases quickly and easily. It provides an efficient API that minimizes the amount of code needed to get results from the database.",
                    ImageUrl = "",
                    Occupancy = 5,
                    Rate = 500,
                    Sqft = 500,
                    Amenity = ""
                }
                );
        }
    }
}
