﻿namespace CachingDemo.Models
{
	public record ProductCreationDTO(string ProductName, string Description, float Price);
}
