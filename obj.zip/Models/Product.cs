﻿namespace CachingDemo.Models
{
	public class Product
	{
        public Guid Id { get; set; }
		public string ProductName { get; set; } = default!;
		public string Description { get; set; } = default!;
		public float Price { get; set; }

		private Product() { }

        public Product(string productname, string description, float price)
        {
            Id = Guid.NewGuid();
			ProductName = productname;
			Description = description;
			Price = price;
        }
    }
}
