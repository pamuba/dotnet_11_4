using CachingDemo.Models;
using CachingDemo.Persistence;
using CachingDemo.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddMemoryCache();

builder.Services.AddDbContext<AppDbContext>(options => {
	options.UseSqlServer(builder.Configuration.GetConnectionString("ConnectionString"));
});

builder.Services.AddTransient<IProductService, ProductService>();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
	app.UseSwagger();
	app.UseSwaggerUI(options => options.DisplayRequestDuration());
}

app.MapGet("/products", async(IProductService service) => {
	var products = service.GetAll();
	return Results.Ok(products);
});

app.MapGet("/products/{id:guid}", async (Guid id, IProductService service) => {
	var product = service.Get(id);
	return Results.Ok(product);
});

app.MapPost("/products", async (ProductCreationDTO product, IProductService service) => {
	await service.Add(product);
	return Results.Created();
});


app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
