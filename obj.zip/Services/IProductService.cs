﻿using CachingDemo.Models;

namespace CachingDemo.Services
{
	public interface IProductService
	{
		Task<Product> Get(Guid id);
		Task<List<Product>> GetAll();
		Task Add(ProductCreationDTO product);
	}
}
