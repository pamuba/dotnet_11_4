﻿using CachingDemo.Models;
using CachingDemo.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;

namespace CachingDemo.Services
{
	public class ProductService(AppDbContext dbContext, 
		IMemoryCache cache, ILogger<ProductService> logger) : IProductService
	{
		public async Task Add(ProductCreationDTO request)
		{
			var product = new Product(request.ProductName, request.Description, request.Price);
			await dbContext.Products.AddAsync(product);
			await dbContext.SaveChangesAsync();
			//invalidate cache for products, as new product is added
			var cacheKey = "products";
			logger.LogInformation("invalidating cache for key:{cacheKey} from cache",cacheKey);
			cache.Remove(cacheKey);
		}

		public async Task<Product> Get(Guid id)
		{
			var cacheKey = $"product{id.ToString()}";
			logger.LogInformation("fetching data for key:{cacheKey} from cache", cacheKey);
			if (!cache.TryGetValue(cacheKey, out Product? product))
			{
				logger.LogInformation("cache miss fetching data for key:{cacheKey} from database", cacheKey);
				product = await dbContext.Products.FindAsync(id);

				var cacheOptions = new MemoryCacheEntryOptions()
					.SetAbsoluteExpiration(TimeSpan.FromMinutes(50))
					.SetSlidingExpiration(TimeSpan.FromMinutes(5))
					.SetPriority(CacheItemPriority.Normal)
					.SetSize(2084);

				logger.LogInformation("setting data for key:{cacheKey} to cache", cacheKey);
				cache.Set(cacheKey, product, cacheOptions);
			}
			else {
				logger.LogInformation("cache hit for key:{cacheKey} in the cache", cacheKey);
			}
			return product;

		}

		public async Task<List<Product>> GetAll()
		{
			var cacheKey = "products";
			logger.LogInformation("fetching data for key:{cacheKey} from cache", cacheKey);
			if (!cache.TryGetValue(cacheKey, out List<Product>? products))
			{
				logger.LogInformation("cache miss fetching data for key:{cacheKey} from database", cacheKey);
				products = await dbContext.Products.ToListAsync();

				var cacheOptions = new MemoryCacheEntryOptions()
					.SetAbsoluteExpiration(TimeSpan.FromMinutes(20))
					.SetSlidingExpiration(TimeSpan.FromMinutes(2))
					.SetPriority(CacheItemPriority.NeverRemove);
					
				logger.LogInformation("setting data for key:{cacheKey} to cache", cacheKey);
				cache.Set(cacheKey, products, cacheOptions);
			}
			else
			{
				logger.LogInformation("cache hit for key:{cacheKey} in the cache", cacheKey);
			}
			return products;
		}
	}

	//cache exceeds memoty limits
	//Normal
	//High
	//Low.
	//NeverRemove
}
